### Hexlet tests and linter status:
[![Actions Status](https://github.com/slovohot/python-project-49/workflows/hexlet-check/badge.svg)](https://github.com/slovohot/python-project-49/actions)

[![Maintainability](https://api.codeclimate.com/v1/badges/2ef8c4f8d5975c0c02a5/maintainability)](https://codeclimate.com/github/slovohot/python-project-49/maintainability)

asciinema brain-even: https://asciinema.org/a/yVcHyv3NOiy61PTklsVfZf2vL

asciinema brain-cals: https://asciinema.org/a/usBUb1X6gqYtJpGqBSisTOEPf

asciinema brain-gcd: https://asciinema.org/a/aA34VcfxRi4s5vgHyqCRX6oZo

asciinema brain-progression: https://asciinema.org/a/Vbj6CJGm3OKqV3pQAIFsHXbab

asciinema brain-prime: 