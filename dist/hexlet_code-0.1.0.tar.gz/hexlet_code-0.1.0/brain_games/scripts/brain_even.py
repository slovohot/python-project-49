# import prompt
import random


def welcome_user():
    global name
    name = ''
    while name == '':
        print('May I have your name? ', end='')
        name = input()
    print(f"Hello, {name}!")


def brain_even():
    #Создаем фун-цию, которая будет отвечать за саму игру, создаем
    #глобальные переменные для других фун-ций
    global range_num
    global answer
    global result
    result = 0
    print('Answer "yes" if the number is even, otherwise answer "no"')
    #Цикл для определения трех правильных попыток
    while result < 3:
        range_num = random.randint(1, 100)
        print(f'Question: {range_num}')
        answer = input('Your answer: ')
        if answer == 'yes':
            answer_yes()
        elif answer == 'no':
            answer_no()
        else:
            result = 0
            print(f'Answer "yes" if the number is even, otherwise answer "no"\nLet\'s try again, {name}!\'')
        # print(result)
    print(f'Congratulations, {name}!')


def answer_yes():
    #Функция, если игрок ответил yes
    global result
    if range_num % 2 == 0:
        print('Correct!')
        result += 1
    else:
        print(f"'yes' is wrong answer ;(. Correct answer was 'no'. \nLet's try again, {name}!")
        result = 0


def answer_no():
    #Функция, если игрок ответил no
    global result
    if range_num % 2 != 0:
        print('Correct!')
        result += 1
    else:
        print(f"'no' is wrong answer ;(. Correct answer was 'yes'. \nLet's try again, {name}!")
        result = 0


def greet():
    print("Welcome to the Brain Games!")
    welcome_user()
    brain_even()


def main():
    greet()


if __name__ == '__main__':
    main()
